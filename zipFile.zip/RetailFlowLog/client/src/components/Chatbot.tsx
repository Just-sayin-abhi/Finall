"use client";

import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type Message = {
  role: "user" | "assistant" | "system";
  content: string;
};

export default function Chatbot() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [systemPrompt, setSystemPrompt] = useState<string>("");
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Read visible food items on page (only items rendered and visible in the DOM)
  function readVisibleFoods(): string[] {
    try {
      const nodes = Array.from(document.querySelectorAll('[data-testid^="food-card-"]')) as HTMLElement[];
      // Filter out invisible ones (display: none or not in document flow)
      const visible = nodes.filter((n) => {
        const rect = n.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0;
      });
      // Extract the name header if present
      const names = visible.map((n) => {
        const h = n.querySelector("h4");
        return (h?.textContent || n.textContent || "").trim();
      }).filter(Boolean);
      return names;
    } catch (e) {
      return [];
    }
  }

  function buildSystemPrompt(visibleFoods: string[]) {
    const list = visibleFoods.join(", ");
    return `You are a food recommendation assistant and an ayurvedic dietician. Use only the following foods available on the page: ${list}. Prioritize recommendations from the top of the list. When suggesting meals or swaps, only reference items from that list and avoid introducing external foods.`;
  }

  useEffect(() => {
    // initial system message is kept out of the visible message list
    const visible = readVisibleFoods();
    const sp = buildSystemPrompt(visible);
    setSystemPrompt(sp);
  }, []);

  useEffect(() => {
    // auto-scroll on messages change
    if (!containerRef.current) return;
    containerRef.current.scrollTop = containerRef.current.scrollHeight;
  }, [messages]);

  async function handleSend() {
    if (!input.trim()) return;
    const userMsg: Message = { role: "user", content: input.trim() };
    setMessages((m) => [...m, userMsg]);
    setInput("");
    setLoading(true);

    // Rebuild system prompt from current visible foods (must only use visible items)
    const visible = readVisibleFoods();
    const sp = buildSystemPrompt(visible);

    try {
      const hostname = window.location.hostname;
      const isLocal = hostname === "localhost" || hostname === "127.0.0.1" || hostname === "0.0.0.0";
      const endpoint = isLocal ? "/api/chat-dev" : "/api/chat";

      const resp = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ system: sp || systemPrompt, message: userMsg.content }),
      });
      if (!resp.ok) {
        const err = await resp.json().catch(() => ({ message: "Request failed" }));
        setMessages((m) => [...m, { role: "assistant", content: `Error: ${err.message || 'failed'}` }]);
        return;
      }
      const data = await resp.json();
      const assistantText = data?.content || data?.message || "No response";
      setMessages((m) => [...m, { role: "assistant", content: assistantText }]);
    } catch (e: any) {
      setMessages((m) => [...m, { role: "assistant", content: `Error: ${e?.message || 'request failed'}` }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="w-full max-w-xl border rounded-lg p-4 bg-card">
      <div className="flex items-center justify-between mb-2">
        <h4 className="font-medium">Diet Chat</h4>
        <small className="text-xs text-muted-foreground">Uses only visible foods</small>
      </div>

      <div ref={containerRef} className="h-64 overflow-auto mb-3 p-3 bg-background rounded">
        {messages.map((m, i) => (
          <div key={i} className={`mb-3 ${m.role === 'assistant' ? 'text-left' : 'text-right'}`}>
            <div className={`inline-block max-w-full break-words px-3 py-2 rounded ${m.role === 'assistant' ? 'bg-muted' : 'bg-primary/10'}`}>
              {m.content}
            </div>
          </div>
        ))}
      </div>

      <div className="flex gap-2">
        <Input value={input} onChange={(e:any) => setInput(e.target.value)} placeholder="Ask about these foods..." />
        <Button onClick={handleSend} disabled={loading}>
          {loading ? "..." : "Send"}
        </Button>
      </div>
    </div>
  );
}
